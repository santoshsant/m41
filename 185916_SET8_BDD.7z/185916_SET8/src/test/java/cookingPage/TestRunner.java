package cookingPage;

import org.junit.runner.RunWith;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(plugin = { "pretty" },features = {"D:\\Users\\npadmana\\Desktop\\Codes\\185916_SET8\\src\\test\\resources\\cooking\\cooking.feature"})
public class TestRunner {

}